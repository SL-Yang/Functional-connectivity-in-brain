import { ShaderMaterialParameters, ShaderMaterial } from './ShaderMaterial';

export class ShadowMaterial extends ShaderMaterial {
  constructor(parameters?: ShaderMaterialParameters);
}
