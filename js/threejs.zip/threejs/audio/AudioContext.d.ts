export const AudioContext: AudioContext;
